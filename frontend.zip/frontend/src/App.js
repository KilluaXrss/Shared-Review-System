import { Routes, Route, useLocation } from "react-router";
import Signup from "./pages/Signup";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import NotFound from "./pages/Notfound";
import Category from "./pages/Category";  
import Profiles from "./pages/Profiles";
import ProfileDetail from "./pages/Profiles";
import Item from "./pages/Item";  
import ItemDetail from './pages/ItemDetail';   
import Navbar from "./components/Navbar";
import Notifications from "./pages/Notifications";
import UserProfile from './pages/UserProfile';
import Chat from "./pages/Chat";
import ResetPassword from "./pages/ResetPassword";
import ForgotPassword from "./pages/ForgotPassword";


function App() {
  const location = useLocation();

  // Define paths where the Navbar should be hidden
  const hideNavbarPaths = ["/login", "/signup"];

  const shouldShowNavbar = !hideNavbarPaths.includes(location.pathname.toLowerCase());

  return (
    <>
      {shouldShowNavbar && <Navbar />} {/* ✅ Conditional rendering */}

      <div >
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/login" element={<Login />} />
          <Route path="/home" element={<Home />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/chat" element={<Chat />} />
          <Route path="/chat/:otherUserId" element={<Chat />} />
          <Route path="/category" element={<Category />} />
          <Route path="/profiles" element={<Profiles />} />
          <Route path= "/Notifications" element={<Notifications />} />
          <Route path="/users/:userId" element={<UserProfile />} />
          <Route path="/profile/:userId" element={<ProfileDetail />} />
          <Route path="/category/:categoryId" element={<Item />} />
          <Route path="/itemdetail/:itemId" element={<ItemDetail />} />
          <Route path="/item/:itemId" element={<ItemDetail />} />
          <Route path="/reset-password/:token" element={<ResetPassword />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </div>
    </>
  );
}

export default App;
