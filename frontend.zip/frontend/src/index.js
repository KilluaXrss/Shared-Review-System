import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router"; // ✅ Correct import
import "./css/index.css";
import App from "./App";

const script = document.createElement("script");
script.src = "https://accounts.google.com/gsi/client";
script.async = true;
script.defer = true;
document.body.appendChild(script);

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <BrowserRouter>
    <React.StrictMode>
      <App />
    </React.StrictMode>
  </BrowserRouter>
);
