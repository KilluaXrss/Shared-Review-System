import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";

const Chat = () => {
  const { otherUserId } = useParams();
  const navigate = useNavigate();

  const [friends, setFriends] = useState([]);
  const [messages, setMessages] = useState([]);
  const [newMsg, setNewMsg] = useState("");
  const [userId, setUserId] = useState(null);
  const [selectedUserId, setSelectedUserId] = useState(null);

  useEffect(() => {
    fetch("http://localhost:4000/current-user", { credentials: "include" })
      .then(res => res.json())
      .then(data => setUserId(data.userId))
      .catch(err => console.error("Error fetching userId:", err));
  }, []);

  useEffect(() => {
    fetch("http://localhost:4000/friends", { credentials: "include" })
      .then(res => res.json())
      .then(data => {
        console.log("Fetched friends data:", data);
        setFriends(data);
      })
      .catch(err => console.error("Error fetching friends:", err));
  }, []);

  useEffect(() => {
    if (!selectedUserId) return;

    fetch(`http://localhost:4000/chat/${selectedUserId}`, {
      credentials: "include",
    })
      .then(res => res.json())
      .then(data => setMessages(Array.isArray(data) ? data : []))
      .catch(err => console.error("Error fetching messages:", err));

    fetch(`http://localhost:4000/chat/${selectedUserId}/read`, {
      method: "POST",
      credentials: "include",
    })
      .then(() => {
        setFriends(prev =>
          prev.map(friend =>
            String(friend.user_id) === String(selectedUserId)
              ? { ...friend, unreadcount: 0 }
              : friend
          )
        );
      })
      .catch(err => console.error("Error marking as read:", err));
  }, [selectedUserId]);

  const sendMessage = () => {
    if (!newMsg.trim()) return;

    fetch("http://localhost:4000/chat", {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ receiver_id: selectedUserId, message: newMsg }),
    })
      .then(res => res.json())
      .then(msg => {
        setMessages(prev => [...prev, msg]);
        setNewMsg("");
      })
      .catch(err => console.error("Error sending message:", err));
  };

  const handleFriendClick = (id) => {
    if (selectedUserId === id) {
      setSelectedUserId(null);
      navigate("/chat");
    } else {
      setSelectedUserId(id);
      navigate(`/chat/${id}`);
    }

    setFriends(prev =>
      prev.map(friend =>
        String(friend.user_id) === String(id)
          ? { ...friend, unreadcount: 0 }
          : friend
      )
    );
  };

  const selectedFriend = friends.find(f => String(f.user_id) === String(selectedUserId));
  const friendUsername = selectedFriend?.username || "Them";

  return (
    <div style={{ display: "flex", height: "90vh", fontFamily: "Segoe UI, sans-serif" }}>

      {/* Friend List */}
      <div style={{
        width: "28%",
        borderRight: "1px solid #ccc",
        background: "#f0f2f5",
        padding: "1rem",
        overflowY: "auto"
      }}>
        <h3 style={{ margin: "0 0 1rem 0" }}>Friends</h3>
        {friends.map(friend => {
          const unreadCount = parseInt(friend.unreadcount) || 0;
          const isActive = selectedUserId == friend.user_id;

          return (
            <div key={friend.user_id}
                 onClick={() => handleFriendClick(friend.user_id)}
                 style={{
                   backgroundColor: isActive ? "#e6f7ff" : "#fff",
                   border: "1px solid #d9d9d9",
                   borderRadius: "10px",
                   marginBottom: "8px",
                   padding: "10px 14px",
                   cursor: "pointer",
                   display: "flex",
                   justifyContent: "space-between",
                   alignItems: "center",
                   boxShadow: isActive ? "0 0 8px rgba(0,123,255,0.2)" : "0 0 3px rgba(0,0,0,0.05)",
                   transition: "all 0.2s ease-in-out"
                 }}>
              <span>{friend.username}</span>
              {unreadCount > 0 && (
                <span style={{
                  backgroundColor: "#f5222d",
                  color: "#fff",
                  fontWeight: "bold",
                  fontSize: "0.75rem",
                  borderRadius: "50px",
                  padding: "2px 8px",
                  minWidth: "20px",
                  textAlign: "center"
                }}>{unreadCount}</span>
              )}
            </div>
          );
        })}
      </div>

      {/* Chat Window */}
      {selectedUserId && (
        <div style={{
          flex: 1,
          padding: "1rem",
          display: "flex",
          flexDirection: "column",
          backgroundColor: "#ffffff",
          borderLeft: "1px solid #ccc"
        }}>
          {/* Messages */}
          <div style={{
            flex: 1,
            overflowY: "auto",
            marginBottom: "1rem",
            backgroundColor: "#f1f1f1",
            padding: "10px",
            borderRadius: "5px"
          }}>
            {messages.map((msg) => (
              <div
                key={msg.message_id}
                style={{
                  marginBottom: "0.5rem",
                  backgroundColor: msg.sender_id === userId ? "#d0f0fd" : "#fff",
                  padding: "8px 12px",
                  borderRadius: "10px",
                  maxWidth: "70%",
                  marginLeft: msg.sender_id === userId ? "auto" : "0",
                  textAlign: msg.sender_id === userId ? "right" : "left",
                  boxShadow: "0 1px 3px rgba(0,0,0,0.1)"
                }}
              >
                <strong>
                  {msg.sender_id === parseInt(selectedUserId)
                    ? friendUsername
                    : "You"}
                  :
                </strong> {msg.message}
              </div>
            ))}
          </div>

          {/* Input Box */}
          <div style={{ display: "flex", gap: "10px" }}>
            <input
              value={newMsg}
              onChange={(e) => setNewMsg(e.target.value)}
              placeholder="Type your message"
              style={{
                flex: 1,
                padding: "0.5rem",
                border: "1px solid #ccc",
                borderRadius: "5px",
                outline: "none"
              }}
            />
            <button
              onClick={sendMessage}
              style={{
                padding: "0.5rem 1rem",
                backgroundColor: "#1da1f2",
                color: "white",
                border: "none",
                borderRadius: "5px",
                cursor: "pointer"
              }}
            >
              Send
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Chat;