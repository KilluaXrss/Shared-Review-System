// src/components/VerificationForm.jsx
import React, { useState } from 'react';
import { apiUrl } from "../config/config";
import "../css/verification.css";

const VerificationForm = ({ email, onVerificationSuccess }) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleVerify = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await fetch(`${apiUrl}/verify-email`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ email, pin }),
      });

      const data = await response.json();

      if (response.ok) {
        onVerificationSuccess();
      } else {
        setError(data.message || 'Verification failed');
      }
    } catch (err) {
      setError('Failed to verify email. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleResendPin = async () => {
    setLoading(true);
    setError('');

    try {
      const response = await fetch(`${apiUrl}/resend-verification`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ email }),
      });

      const data = await response.json();

      if (response.ok) {
        alert('New PIN sent to your email!');
      } else {
        setError(data.message || 'Failed to resend PIN');
      }
    } catch (err) {
      setError('Failed to resend PIN. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="verification-container">
      <h2>Email Verification</h2>
      <p>Please enter the verification PIN sent to {email}</p>
      
      {error && <div className="error-message">{error}</div>}
      
      <form onSubmit={handleVerify} className="verification-form">
        <input
          type="text"
          value={pin}
          onChange={(e) => setPin(e.target.value)}
          placeholder="Enter 6-digit PIN"
          maxLength="6"
          required
        />
        
        <button type="submit" disabled={loading}>
          {loading ? 'Verifying...' : 'Verify PIN'}
        </button>
      </form>

      <button 
        onClick={handleResendPin} 
        className="resend-button"
        disabled={loading}
      >
        Resend PIN
      </button>
    </div>
  );
};

export default VerificationForm;