import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router";
import "../css/ItemDetail.css";

const ItemDetail = () => {
  const { itemId } = useParams();
  const navigate = useNavigate();

  const [item, setItem] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [username, setUsername] = useState(null);
  const [userRating, setUserRating] = useState(0);
  const [newReview, setNewReview] = useState("");
  const [userReview, setUserReview] = useState(null);
  const [averageRating, setAverageRating] = useState(null);
  const [editing, setEditing] = useState(false);

  const [likes, setLikes] = useState({});
  const [commentInputs, setCommentInputs] = useState({});
  const [reviewComments, setReviewComments] = useState({});
  const [visibleComments, setVisibleComments] = useState({});

  const [status, setStatus] = useState("");

  const baseUrl = 'http://localhost:4000';

  const normalizeProfilePic = (path) => {
    if (!path) return null;
    const normalized = path.replace('/uploads//uploads/', '/uploads/');
    return `${baseUrl}${normalized}`;
  };

  useEffect(() => {
    fetchItemDetails();
    fetchUsername();
  }, [itemId]);

  useEffect(() => {
    if (username) {
      fetchReviews();
      fetchStatus();
    }
  }, [username]);

  const fetchStatus = async () => {
    try {
      const res = await fetch(`http://localhost:4000/item/${itemId}/status`, {
        credentials: "include",
      });
      if (!res.ok) return;
      const data = await res.json();
      setStatus(data.status);
    } catch (error) {
      console.error("Error fetching status:", error);
    }
  };

  const handleStatusChange = async (e) => {
    const newStatus = e.target.value;
    setStatus(newStatus);
    try {
      await fetch(`http://localhost:4000/item/${itemId}/status`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus }),
      });
    } catch (error) {
      console.error("Error updating status:", error);
    }
  };

  const getStatusOptions = () => {
    if (!item?.category_id) return [];
    switch (item.category_id) {
      case 1: return ["Want to Watch", "Watching", "Watched"];
      case 2: return ["Want to Read", "Reading", "Read Already"];
      case 3: return ["Want to Learn", "Learning", "Learned"];
      case 4: return ["Want to Watch", "Watching", "Watched"];
      case 5: return [ "want to read", "reading", "read"];
      case 6: return ["want to read", "reading", "read"];

      
      default: return ["Interested", "In Progress", "Completed"];
    }
  };

  const fetchItemDetails = async () => {
    try {
      const res = await fetch(`http://localhost:4000/item/${itemId}`);
      const data = await res.json();
      setItem(data);
    } catch (error) {
      console.error("Error fetching item:", error);
    }
  };

  const fetchUsername = async () => {
    try {
      const res = await fetch("http://localhost:4000/isLoggedIn", {
        credentials: "include",
      });
      if (!res.ok) return;
      const data = await res.json();
      setUsername(data.username);
    } catch (error) {
      console.error("Error fetching username:", error);
    }
  };

  const fetchReviews = async () => {
    try {
      const res = await fetch(`http://localhost:4000/item/${itemId}/reviews`);
      const data = await res.json();
      const normalizedReviews = data.map((review) => ({
        ...review,
        profile_pic: normalizeProfilePic(review.profile_pic),
      }));
      setReviews(normalizedReviews);

      if (data.length > 0) {
        const avg = (data.reduce((sum, r) => sum + r.rating, 0) / data.length).toFixed(1);
        setAverageRating(avg);
      } else {
        setAverageRating(null);
      }

      const myReview = data.find((r) => r.username === username);
      if (myReview) {
        setUserReview(myReview);
        setUserRating(myReview.rating);
        setNewReview(myReview.review);
      } else {
        setUserReview(null);
        setUserRating(0);
        setNewReview("");
      }

      data.forEach((review) => {
        fetchLikes(review.rating_id);
        fetchComments(review.rating_id);
      });
    } catch (error) {
      console.error("Error fetching reviews:", error);
    }
  };

  const fetchLikes = async (ratingId) => {
    try {
      const res = await fetch(`http://localhost:4000/ratings/${ratingId}/likes`);
      const data = await res.json();
      setLikes((prev) => ({ ...prev, [ratingId]: data.likeCount }));
    } catch (err) {
      console.error("Error fetching likes:", err);
    }
  };

  const toggleLike = async (ratingId) => {
    try {
      const res = await fetch(`http://localhost:4000/ratings/${ratingId}/like`, {
        method: "POST",
        credentials: "include",
      });
      const data = await res.json();
      fetchLikes(ratingId);
    } catch (err) {
      console.error("Error liking review:", err);
    }
  };

  const fetchComments = async (ratingId) => {
    try {
      const res = await fetch(`http://localhost:4000/ratings/${ratingId}/comments`);
      const data = await res.json();
      setReviewComments((prev) => ({ ...prev, [ratingId]: data }));
    } catch (err) {
      console.error("Error fetching comments:", err);
    }
  };

  const postComment = async (ratingId) => {
    try {
      const res = await fetch(`http://localhost:4000/ratings/${ratingId}/comments`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ comment: commentInputs[ratingId] }),
      });
      if (res.ok) {
        fetchComments(ratingId);
        setCommentInputs((prev) => ({ ...prev, [ratingId]: "" }));
      }
    } catch (err) {
      console.error("Error posting comment:", err);
    }
  };

  const handleReviewSubmit = async () => {
    try {
      const method = userReview ? "PUT" : "POST";
      await fetch(`http://localhost:4000/item/${itemId}/review`, {
        method,
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rating: userRating, review: newReview }),
      });
      setEditing(false);
      fetchReviews();
    } catch (error) {
      console.error("Error submitting review:", error);
    }
  };

  const handleDeleteReview = async () => {
    if (!window.confirm("Are you sure you want to delete your review?")) return;
    window.location.reload();
    try {
      await fetch(`http://localhost:4000/item/${itemId}/review`, {
        method: "DELETE",
        credentials: "include",
      });
      setUserReview(null);
      setUserRating(0);
      setNewReview("");
      setEditing(false);
      fetchReviews();
    } catch (error) {
      console.error("Error deleting review:", error);
    }
  };

  const handleStarClick = async (starValue) => {
    setUserRating(starValue);
  
    try {
      const method = userReview ? "PUT" : "POST";
      await fetch(`http://localhost:4000/item/${itemId}/review`, {
        method,
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rating: starValue, review: newReview }),
      });
  
      fetchReviews(); // Refresh reviews and rating info
      fetchItemDetails();
    } catch (error) {
      console.error("Error auto-submitting rating:", error);
    }
  };
  

  const toggleComments = (ratingId) => {
    setVisibleComments((prev) => ({
      ...prev,
      [ratingId]: !prev[ratingId],
    }));
  };

  const goToUserProfile = (userId) => {
    navigate(`/users/${userId}`);
  };

  if (!item) return <div>Loading...</div>;

  return (
    <div className="item-detail">
      <button onClick={() => navigate(-1)}>← Back</button>

      <div className="item-header">
        <img src={item.image_url} alt={item.title} />
        <div>
          <h1>{item.title}</h1>
          {item.description && (
            <>
              <h3>Description</h3>
              <p>{item.description}</p>
            </>
          )}
          {item.genre && <p><strong>Genre:</strong> {item.genre}</p>}
          {item.release_year && <p><strong>Release Year:</strong> {item.release_year}</p>}
          <h3>
            Average Rating:{" "}
            {averageRating != null && !isNaN(averageRating)
              ? `⭐ ${averageRating}`
              : "No ratings yet"}
            {reviews.length > 0
              ? ` (${reviews.length} rating${reviews.length > 1 ? "s" : ""})`
              : ""}
          </h3>
          {username && (
            <div className="your-rating-inline">
              <strong>Your Rating: </strong>
              {[1, 2, 3, 4, 5].map((star) => (
                <span
                  key={star}
                  className={star <= userRating ? "star filled" : "star"}
                  onClick={() => handleStarClick(star)}
                >
                  ★
                </span>
              ))}
            </div>
          )}
          {username && (
            <div className="status-select">
              <label><strong>Status: </strong></label>
              <select value={status} onChange={handleStatusChange}>
                <option value="">Select Status</option>
                {getStatusOptions().map((opt) => (
                  <option key={opt} value={opt}>{opt}</option>
                ))}
              </select>
            </div>
          )}
        </div>
      </div>

      <div className="reviews-section">
      <h3>
  Reviews ({reviews.filter(r => r.review && r.review.trim() !== "").length})
</h3>
        {reviews.length > 0 ? (
          <ul>
            {reviews
              .filter((review) => review.review && review.review.trim() !== "")
              .map((review, index) => (
              <li key={index} className="review-box">
                <div className="review-user">
                {review.profile_pic ? (
              <img
                src={review.profile_pic}
                alt={review.username}
                className="profile-pic"
              />
            ) : (
              <div className="initials-fallback">
                {review.username[0]}
              </div>
            )}
                  <strong
                    onClick={() => goToUserProfile(review.user_id)}
                    className="review-username"
                  >
                    {review.username}
                  </strong>
                  <span> ({review.rating} ⭐)</span>
                </div>
                <p>{review.review}</p>

                <button onClick={() => toggleLike(review.rating_id)}>
                  👍 {likes[review.rating_id] || 0}
                </button>

                <button onClick={() => toggleComments(review.rating_id)}>
                  💬 {reviewComments[review.rating_id]?.length || 0}
                </button>

                {visibleComments[review.rating_id] && (
                  <div className="comments-section">
                    <ul>
                      {(reviewComments[review.rating_id] || []).map((c) => (
                        <li key={c.comment_id}>
                          <strong>{c.username}</strong>: {c.comment}
                        </li>
                      ))}
                    </ul>

                    {username && (
                      <div className="comment-form">
                        <input
                          value={commentInputs[review.rating_id] || ""}
                          onChange={(e) =>
                            setCommentInputs((prev) => ({
                              ...prev,
                              [review.rating_id]: e.target.value,
                            }))
                          }
                          placeholder="Write a comment..."
                        />
                        <button onClick={() => postComment(review.rating_id)}>Post</button>
                      </div>
                    )}
                  </div>
                )}
              </li>
            ))}
          </ul>
        ) : (
          <p>No reviews yet</p>
        )}

        {username && (
          <div className="user-review-section">
            {username && (
              <div className="user-review-section">
                {userReview && userReview.review && !editing ? (
                  <div className="your-review">
                    <h4>Your Review</h4>
                    <p>Rating: {userReview.rating} ⭐</p>
                    <p>{userReview.review}</p>
                    <button onClick={() => setEditing(true)}>✏️ Edit</button>
                    <button onClick={handleDeleteReview} className="delete-btn">🗑️ Delete</button>
                  </div>
                ) : (
                  <div className="review-form">
                    <h4>{userReview && userReview.review ? "Edit Your Review" : "Write a Review"}</h4>
                    <div className="star-rating">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <span
                          key={star}
                          className={star <= userRating ? "star filled" : "star"}
                          onClick={() => handleStarClick(star)}
                        >
                          ★
                        </span>
                      ))}
                    </div>
                    <textarea
                      value={newReview}
                      onChange={(e) => setNewReview(e.target.value)}
                      placeholder="Write your review..."
                    />
                    <button onClick={handleReviewSubmit}>
                      {userReview && userReview.review ? "Update Review" : "Submit Review"}
                    </button>
                  </div>
                )}
              </div>
            )}

          </div>
        )}
      </div>
    </div>
  );
};

export default ItemDetail;