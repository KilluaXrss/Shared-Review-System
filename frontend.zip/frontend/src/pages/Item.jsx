import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from 'react-router';
import "../css/Item.css"; // Assuming you have some CSS for styling

const Item = () => {
  const { categoryId } = useParams();
  const navigate = useNavigate();

  const [items, setItems] = useState([]);
  const [filteredItems, setFilteredItems] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortOption, setSortOption] = useState("title");
  const [selectedGenre, setSelectedGenre] = useState("");
  const [showGenreDropdown, setShowGenreDropdown] = useState(false);
  const [allGenres, setAllGenres] = useState([]);
  const [userRatings, setUserRatings] = useState({});

  useEffect(() => {
    fetchItems();
  }, [categoryId]);

  useEffect(() => {
    applySearchAndSort();
  }, [items, searchQuery, sortOption, selectedGenre]);

  const fetchItems = async () => {
    try {
      const response = await fetch(`http://localhost:4000/category/${categoryId}/items`);
      if (!response.ok) throw new Error("Failed to fetch items");
      const data = await response.json();
      fetchAllRatings(data);
    } catch (error) {
      console.error("Error fetching items:", error);
    }
  };

  const fetchAllRatings = async (items) => {
    const ratings = {};
    const ratingCounts = {}; // Store non-empty rating counts
    const userRatingsMap = {};
    const genres = new Set();

    for (const item of items) {
      try {
        const response = await fetch(`http://localhost:4000/item/${item.item_id}/reviews`, {
          credentials: "include",
        });

        if (response.ok) {
          const data = await response.json();

          // Filter out empty reviews (but count the rating)
          const nonEmptyRatings = data.filter((r) => r.rating !== null && r.rating !== undefined);

          // Calculate average rating
          ratings[item.item_id] =
            data.length > 0 ? (data.reduce((sum, r) => sum + r.rating, 0) / data.length).toFixed(1) : null;

          // Count non-empty ratings
          ratingCounts[item.item_id] = nonEmptyRatings.length;

          // Get current user's rating (from new field)
          const currentUserRating = data.find((r) => r.is_current_user);
          if (currentUserRating) {
            userRatingsMap[item.item_id] = currentUserRating.rating;
          }
        }

        if (item.genre) {
          genres.add(item.genre);
        }
      } catch (err) {
        console.error(`Error fetching rating for item ${item.item_id}`, err);
      }
    }

    const updatedItems = items.map((item) => ({
      ...item,
      avg_rating: ratings[item.item_id],
      rating_count: ratingCounts[item.item_id], // Add rating count to item
    }));

    setItems(updatedItems);
    setUserRatings(userRatingsMap); // ✅ this ensures your stars show up correctly
    setAllGenres([...genres]);
  };

  const applySearchAndSort = () => {
    let result = [...items];

    if (searchQuery) {
      result = result.filter(item =>
        item.title.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (selectedGenre) {
      result = result.filter(item => item.genre === selectedGenre);
    }

    switch (sortOption) {
      case "title":
        result.sort((a, b) => a.title.localeCompare(b.title));
        break;
      case "genre":
        result.sort((a, b) => (a.genre || "").localeCompare(b.genre || ""));
        break;
      case "release_date":
        result.sort((a, b) => new Date(a.release_date) - new Date(b.release_date));
        break;
      case "latest":
        result.sort((a, b) => new Date(b.release_date) - new Date(a.release_date));
        break;
      case "trending":
      case "rating":
        result.sort((a, b) => (b.avg_rating || 0) - (a.avg_rating || 0));
        break;
      default:
        break;
    }

    setFilteredItems(result);
  };

  const handleStarClick = async (itemId, rating) => {
    try {
      const res = await fetch(`http://localhost:4000/item/${itemId}/review`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rating, review: "" }),
      });
      if (res.ok) {
        setUserRatings((prev) => ({ ...prev, [itemId]: rating }));
        fetchItems(); // to refresh avg rating
      }
    } catch (err) {
      console.error("Failed to rate item", err);
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <h1 style={{ textAlign: "center" }}>Items</h1>

      <div style={{ marginBottom: "20px" }}>
        <input
          type="text"
          placeholder="Search items..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          style={{ padding: "8px", width: "300px", marginBottom: "10px" }}
        />

        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-start", gap: "10px" }}>
          <label style={{ fontWeight: "bold" }}>Sort by:</label>

          <div style={{ display: "flex", flexWrap: "wrap", gap: "10px", position: "relative" }}>
            <button
              onClick={() => setSortOption("title")}
              style={{
                padding: "6px 12px",
                border: "1px solid #ccc",
                borderRadius: "5px",
                backgroundColor: sortOption === "title" ? "#eee" : "white",
                color: "#000",
                cursor: "pointer",
              }}
            >
              Alphabetical
            </button>

            <div style={{ position: "relative" }}>
              <button
                onClick={() => setShowGenreDropdown(!showGenreDropdown)}
                style={{
                  padding: "6px 12px",
                  border: "1px solid #ccc",
                  borderRadius: "5px",
                  backgroundColor: selectedGenre ? "#eee" : "white",
                  color: "#000",
                  cursor: "pointer",
                }}
              >
                {selectedGenre ? `Genre: ${selectedGenre}` : "Genre"}
              </button>

              {showGenreDropdown && (
                <div
                  style={{
                    position: "absolute",
                    top: "40px",
                    left: 0,
                    zIndex: 1000,
                    backgroundColor: "#fff",
                    border: "1px solid #ccc",
                    borderRadius: "5px",
                    padding: "10px",
                    display: "flex",
                    flexDirection: "column",
                    minWidth: "150px",
                    maxHeight: "200px",
                    overflowY: "auto",
                  }}
                >
                  <button
                    onClick={() => {
                      setSelectedGenre("");
                      setShowGenreDropdown(false);
                    }}
                    style={{ marginBottom: "5px", cursor: "pointer", textAlign: "left" }}
                  >
                    All Genres
                  </button>
                  {allGenres.map((genre) => (
                    <button
                      key={genre}
                      onClick={() => {
                        setSelectedGenre(genre);
                        setShowGenreDropdown(false);
                      }}
                      style={{ marginBottom: "5px", cursor: "pointer", textAlign: "left" }}
                    >
                      {genre}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <button
              onClick={() => setSortOption("release_date")}
              style={{
                padding: "6px 12px",
                border: "1px solid #ccc",
                borderRadius: "5px",
                backgroundColor: sortOption === "release_date" ? "#eee" : "white",
                color: "#000",
                cursor: "pointer",
              }}
            >
              Release Date
            </button>

            <button
              onClick={() => setSortOption("latest")}
              style={{
                padding: "6px 12px",
                border: "1px solid #ccc",
                borderRadius: "5px",
                backgroundColor: sortOption === "latest" ? "#eee" : "white",
                color: "#000",
                cursor: "pointer",
              }}
            >
              Latest
            </button>

            <button
              onClick={() => setSortOption("rating")}
              style={{
                padding: "6px 12px",
                border: "1px solid #ccc",
                borderRadius: "5px",
                backgroundColor: sortOption === "rating" ? "#eee" : "white",
                color: "#000",
                cursor: "pointer",
              }}
            >
              Rating
            </button>
          </div>
        </div>
      </div>

      <div style={{ display: "flex", flexWrap: "wrap", gap: "20px" }}>
        {filteredItems.length > 0 ? (
          filteredItems.map((item) => (
            <div
              key={item.item_id}
              style={{
                width: "30%",
                border: "1px solid #ccc",
                borderRadius: "10px",
                padding: "10px",
                boxSizing: "border-box",
              }}
            >
              <img
                src={item.image_url}
                alt={item.title}
                style={{
                  width: "100%",
                  height: "300px",
                  objectFit: 'cover',
                  borderRadius: "10px",
                  cursor: "pointer"
                }}
                onClick={() => navigate(`/itemdetail/${item.item_id}`)}
              />
              <h3>{item.title}</h3>
              <p><strong>Genre:</strong> {item.genre || "N/A"}</p>
              <div style={{ marginTop: "10px" }}>
                <p>
                  <strong>Avg Rating:</strong> {item.avg_rating || "N/A"} ⭐ ({item.rating_count || 0} ratings)
                </p>
                
                {/* User Star Rating */}
                <div style={{ display: "flex", cursor: "pointer" }}>
                  {[1, 2, 3, 4, 5].map((star) => (
                    <span
                      key={star}
                      style={{
                        fontSize: "20px",
                        color: (userRatings[item.item_id] || 0) >= star ? "#ffc107" : "#ccc",
                        marginRight: "5px",
                      }}
                      onClick={() => handleStarClick(item.item_id, star)}
                    >
                      ★
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))
        ) : (
          <p>No items available in this category.</p>
        )}
      </div>


      <div style={{ marginTop: "40px" }}>
        <button
          onClick={() => navigate('/dashboard')}
          style={{ padding: "10px 20px", fontSize: "16px" }}
        >
          ⬅ Back to Dashboard
        </button>
      </div>
    </div>
  );
};

export default Item;
