import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router";

const Item = () => {
  const { categoryId } = useParams();
  const navigate = useNavigate();
  const [items, setItems] = useState([]);
  const [filteredItems, setFilteredItems] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortOption, setSortOption] = useState("title");

  useEffect(() => {
    fetchItems();
  }, [categoryId]);

  useEffect(() => {
    applySearchAndSort();
  }, [items, searchQuery, sortOption]);

  const fetchItems = async () => {
    try {
      const response = await fetch(`http://localhost:4000/category/${categoryId}/items`);
      if (!response.ok) throw new Error("Failed to fetch items");
      const data = await response.json();
      setItems(data);
    } catch (error) {
      console.error("Error fetching items:", error);
    }
  };

  const applySearchAndSort = () => {
    let result = [...items];

    // Filter by search
    if (searchQuery) {
      result = result.filter(item =>
        item.title.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Sort by selected option
    switch (sortOption) {
      case "title":
        result.sort((a, b) => a.title.localeCompare(b.title));
        break;
      case "genre":
        result.sort((a, b) => (a.genre || "").localeCompare(b.genre || ""));
        break;
      case "release_date":
        result.sort((a, b) => new Date(a.release_date) - new Date(b.release_date));
        break;
      case "latest":
        result.sort((a, b) => new Date(b.release_date) - new Date(a.release_date));
        break;
      case "trending":
        // Assuming trending means higher rating or recent popularity
        result.sort((a, b) => (b.rating || 0) - (a.rating || 0));
        break;
      case "rating":
        result.sort((a, b) => (b.avg_rating || 0) - (a.avg_rating || 0));
        break;
      default:
        break;
    }

    setFilteredItems(result);
  };

  return (
    <div style={{ padding: "20px" }}>
      <h1>Items</h1>

      <div style={{ marginBottom: "20px" }}>
        <input
          type="text"
          placeholder="Search items..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          style={{ padding: "8px", marginRight: "10px", width: "200px" }}
        />
        <select
          value={sortOption}
          onChange={(e) => setSortOption(e.target.value)}
          style={{ padding: "8px" }}
        >
          <option value="title">Alphabetical</option>
          <option value="genre">Genre</option>
          <option value="release_date">Release Date</option>
          <option value="latest">Latest</option>
          <option value="trending">Trending</option>
          <option value="rating">Rating</option>
        </select>
      </div>

      <div style={{ display: "flex", flexWrap: "wrap", gap: "20px" }}>
        {filteredItems.length > 0 ? (
          filteredItems.map((item) => (
            <div
              key={item.item_id}
              style={{
                width: "30%",
                border: "1px solid #ccc",
                borderRadius: "10px",
                padding: "10px",
                boxSizing: "border-box",
              }}
            >
              <img
                src={item.image_url}
                alt={item.title}
                style={{ width: "100%", height: "auto", borderRadius: "10px" }}
              />
              <h3>{item.title}</h3>
              <p><strong>Genre:</strong> {item.genre || "N/A"}</p>
              <button
                onClick={() => navigate(`/item/${item.item_id}`)}
                style={{ padding: "5px 10px" }}
              >
                View Details
              </button>
            </div>
          ))
        ) : (
          <p>No items available in this category.</p>
        )}
      </div>

      <div style={{ marginTop: "40px" }}>
        <button
          onClick={() => navigate('/dashboard')}
          style={{ padding: "10px 20px", fontSize: "16px" }}
        >
          ⬅ Back to Dashboard
        </button>
      </div>
    </div>
  );
};

export default Item;
