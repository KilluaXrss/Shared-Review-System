import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../css/FriendRequests.css';
import { useNavigate } from 'react-router-dom';

const FriendRequests = () => {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const baseUrl = 'http://localhost:4000';

  const normalizeProfilePic = (path) => {
    if (!path) return null;
    const normalized = path.replace('/uploads//uploads/', '/uploads/');
    return `${baseUrl}${normalized}`;
  };

  useEffect(() => {
    const fetchPendingRequests = async () => {
      try {
        const response = await axios.get(`${baseUrl}/friends/pending`, {
          withCredentials: true,
        });
        setRequests(response.data.map((req) => ({
          ...req,
          profile_pic: normalizeProfilePic(req.profile_pic),
        })));
        setLoading(false);
      } catch (err) {
        setError('Failed to load friend requests');
        setLoading(false);
      }
    };
    fetchPendingRequests();
  }, []);

  const acceptRequest = async (friendId) => {
    try {
      await axios.post(
        `${baseUrl}/friends/accept`,
        { friendId },
        { withCredentials: true }
      );
      setRequests((prev) => prev.filter((req) => req.user_id !== friendId));
      // Navigate back to Profiles to refresh the following list
      navigate('/profiles');
    } catch (err) {
      setError('Error accepting friend request');
    }
  };

  const rejectRequest = async (friendId) => {
    try {
      await axios.post(
        `${baseUrl}/friends/reject`,
        { friendId },
        { withCredentials: true }
      );
      setRequests((prev) => prev.filter((req) => req.user_id !== friendId));
    } catch (err) {
      setError('Error rejecting friend request');
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div className="error-message">{error}</div>;

  return (
    <div className="friend-requests-container">
      <h1>Pending Friend Requests</h1>
      {requests.length === 0 ? (
        <p>No pending requests</p>
      ) : (
        <ul className="requests-list">
          {requests.map((request) => (
            <li key={request.user_id} className="request-item">
              <img
                src={request.profile_pic || 'https://via.placeholder.com/50'}
                alt={request.username}
                className="request-pic"
              />
              <span>{request.username}</span>
              <div className="request-buttons">
                <button
                  onClick={() => acceptRequest(request.user_id)}
                  className="accept-btn"
                >
                  Accept
                </button>
                <button
                  onClick={() => rejectRequest(request.user_id)}
                  className="reject-btn"
                >
                  Reject
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
      <div style={{ marginTop: '40px' }}>
        <button
          onClick={() => navigate('/profiles')}
          style={{ padding: '10px 20px', fontSize: '16px' }}
        >
          ⬅ Back to Profiles
        </button>
      </div>
    </div>
  );
};

export default FriendRequests;