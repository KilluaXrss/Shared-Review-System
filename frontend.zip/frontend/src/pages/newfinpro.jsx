import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../css/Profiles.css';
import { useNavigate } from 'react-router-dom';

axios.defaults.withCredentials = true;

const Profiles = () => {
  const [myProfile, setMyProfile] = useState(null);
  const [profiles, setProfiles] = useState([]);
  const navigate = useNavigate();

  const [itemsByStatus, setItemsByStatus] = useState({});
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [statusError, setStatusError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({ username: '', bio: '', profile_pic: null });
  const [fullScreenImage, setFullScreenImage] = useState(null);

  const [followers, setFollowers] = useState([]);
  const [following, setFollowing] = useState([]);
  const [showFollowers, setShowFollowers] = useState(true);
  const [genreSelections, setGenreSelections] = useState([{ id: 1, category: '', genre: '' }]);
  const [availableCategories, setAvailableCategories] = useState([]);
  const [genresForCategory, setGenresForCategory] = useState({});
  const [userFavoriteGenres, setUserFavoriteGenres] = useState([]);
  // Add these new functions in your component
const [editingGenreId, setEditingGenreId] = useState(null);
const [editGenreForm, setEditGenreForm] = useState({ category: '', genre: '' });

// Function to handle genre deletion


  const baseUrl = 'http://localhost:4000';

  const normalizeProfilePic = (path) => {
    if (!path) return null;
    const normalized = path.replace('/uploads//uploads/', '/uploads/');
    return `${baseUrl}${normalized}`;
  };

  // Update the handleEditGenre function
const handleEditGenre = async (categoryId, newGenre) => {
  try {
    await axios.put(`${baseUrl}/user/${myProfile.user_id}/favorite-genre`, {
      categoryId,
      genre: newGenre
    });
    
    // Update the local state directly instead of fetching again
    setUserFavoriteGenres(prevGenres => 
      prevGenres.map(genre => 
        genre.category_id === categoryId 
          ? { ...genre, genre: newGenre }
          : genre
      )
    );
    
    setEditingGenreId(null);
    setEditGenreForm({ category: '', genre: '' });
  } catch (err) {
    console.error('Error updating genre:', err);
    alert('Failed to update genre');
  }
};

// Update the handleDeleteGenre function
const handleDeleteGenre = async (categoryId) => {
  try {
    await axios.delete(`${baseUrl}/user/${myProfile.user_id}/favorite-genre/${categoryId}`);
    
    // Update local state directly
    setUserFavoriteGenres(prevGenres => 
      prevGenres.filter(genre => genre.category_id !== categoryId)
    );
    
    // Make the category available again
    setAvailableCategories(prev => [
      ...prev,
      categories.find(cat => cat.category_id === categoryId)
    ]);
  } catch (err) {
    console.error('Error deleting genre:', err);
    alert('Failed to delete genre');
  }
};

// Update the form submission handler to prevent full profile update
// Update the handleEditSubmit function
const handleEditSubmit = async (e) => {
  e.preventDefault();
  const formData = new FormData();
  
  if (editForm.username) formData.append('username', editForm.username);
  if (editForm.bio !== undefined) formData.append('bio', editForm.bio);
  if (editForm.profile_pic) formData.append('profile_pic', editForm.profile_pic);

  try {
    const response = await axios.put(`${baseUrl}/profiles/update`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });

    const updatedProfile = {
      ...myProfile,
      username: editForm.username || myProfile.username,
      bio: editForm.bio !== undefined ? editForm.bio : myProfile.bio,
      profile_pic: response.data.profile_pic ? `${baseUrl}${response.data.profile_pic}` : myProfile.profile_pic,
    };

    setMyProfile(updatedProfile);
    setEditForm({
      username: updatedProfile.username,
      bio: updatedProfile.bio || '',
      profile_pic: null,
    });
    setIsEditing(false); // This will close the edit form
    
    // Show success message
    alert('Profile updated successfully!');
  } catch (err) {
    console.error('Update error:', err.response?.data);
    alert('Error updating profile: ' + (err.response?.data?.message || 'Unknown error'));
  }
};

  // Function to handle genre edit
  
  const fetchUserFavoriteGenres = async () => {
    if (!myProfile) return;
    try {
      const response = await axios.get(`${baseUrl}/user/${myProfile.user_id}/favorite-genres`);
      setUserFavoriteGenres(response.data);
      updateAvailableCategories(response.data);
    } catch (err) {
      console.error('Error fetching favorite genres:', err);
    }
  };

  const fetchGenresForCategory = async (categoryId) => {
    try {
      const response = await axios.get(`${baseUrl}/category/${categoryId}/genres`);
      setGenresForCategory(prev => ({
        ...prev,
        [categoryId]: response.data
      }));
    } catch (err) {
      console.error('Error fetching genres:', err);
    }
  };

  const updateAvailableCategories = (selectedGenres) => {
    const selectedCategoryIds = selectedGenres.map(g => g.category_id.toString());
    const available = categories.filter(cat => 
      !selectedCategoryIds.includes(cat.category_id.toString())
    );
    setAvailableCategories(available);
  };

  const handleCategorySelect = async (value, index) => {
    const newSelections = [...genreSelections];
    newSelections[index].category = value;
    newSelections[index].genre = '';
    setGenreSelections(newSelections);

    if (value) {
      await fetchGenresForCategory(value);
    }
  };

  const handleGenreSelect = (value, index) => {
    const newSelections = [...genreSelections];
    newSelections[index].genre = value;
    setGenreSelections(newSelections);
  };

  const addNewGenreSelection = () => {
    setGenreSelections(prev => [...prev, { id: Date.now(), category: '', genre: '' }]);
  };

  const saveFavoriteGenre = async (selection) => {
    if (!selection.category || !selection.genre) return;

    try {
      await axios.put(`${baseUrl}/user/${myProfile.user_id}/favorite-genre`, {
        categoryId: selection.category,
        genre: selection.genre
      });

      await fetchUserFavoriteGenres();
      
      setGenreSelections(prev => 
        prev.filter(s => s.id !== selection.id)
      );

      if (genreSelections.length === 1) {
        setGenreSelections([{ id: Date.now(), category: '', genre: '' }]);
      }
    } catch (err) {
      console.error('Error saving favorite genre:', err);
      alert('Failed to save favorite genre');
    }
  };

  // Add this useEffect
  useEffect(() => {
    if (myProfile && categories.length > 0) {
      fetchUserFavoriteGenres();
    }
  }, [myProfile, categories]);
  useEffect(() => {
    const fetchData = async () => {
      try {
        const myProfileResponse = await axios.get(`${baseUrl}/isLoggedIn`);
        const profileData = {
          ...myProfileResponse.data,
          profile_pic: normalizeProfilePic(myProfileResponse.data.profile_pic),
        };
        setMyProfile(profileData);
        setEditForm({
          username: profileData.username,
          bio: profileData.bio || '',
          profile_pic: null,
        });

        const profilesResponse = await axios.get(`${baseUrl}/profiles`);
        const filteredProfiles = profilesResponse.data
          .filter((profile) => profile.username !== profileData.username)
          .map((profile) => ({
            ...profile,
            profile_pic: normalizeProfilePic(profile.profile_pic),
          }));
        setProfiles(filteredProfiles);

        const categoriesResponse = await axios.get(`${baseUrl}/category`);
        setCategories(categoriesResponse.data);

        const statusItemsRes = await axios.get(`${baseUrl}/user/status-items`);
        console.log('Initial itemsByStatus:', statusItemsRes.data); // Debug log
        setItemsByStatus(statusItemsRes.data);

        const followersResponse = await axios.get(`${baseUrl}/followers`);
        setFollowers(followersResponse.data.map((user) => ({
          ...user,
          profile_pic: normalizeProfilePic(user.profile_pic),
        })));

        const followingResponse = await axios.get(`${baseUrl}/following`);
        setFollowing(followingResponse.data.map((user) => ({
          ...user,
          profile_pic: normalizeProfilePic(user.profile_pic),
        })));

        setLoading(false);
      } catch (err) {
        console.error('Fetch error:', err.response?.data);
        setError(err.response?.data?.message || 'Failed to load data');
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    const fetchStatusItems = async () => {
      try {
        const url = selectedCategory
          ? `${baseUrl}/user/status-items?category_id=${selectedCategory}`
          : `${baseUrl}/user/status-items`;
        const statusItemsRes = await axios.get(url);
        console.log('Updated itemsByStatus:', statusItemsRes.data); // Debug log
        setItemsByStatus(statusItemsRes.data);
        setStatusError(null);
      } catch (statusErr) {
        console.error('Status items fetch error:', statusErr.response?.data);
        setStatusError('Failed to load status items');
      }
    };

    if (!loading) fetchStatusItems();
  }, [selectedCategory, loading]);

 

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e) => {
    setEditForm((prev) => ({ ...prev, profile_pic: e.target.files[0] }));
  };

  const sendFriendRequest = async (friendId) => {
    try {
      await axios.post(`${baseUrl}/friends/request`, { friendId });
      alert('Friend request sent!');
    } catch (err) {
      alert('Error sending friend request');
    }
  };

  const openFullScreen = (imageUrl) => {
    setFullScreenImage(imageUrl);
  };

  const closeFullScreen = () => {
    setFullScreenImage(null);
  };

  const goToUserProfile = (userId) => {
    navigate(`/users/${userId}`);
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;

  return (
    <div className="profiles-container">
      <div className="my-profile-section">
  <h1>My Profile</h1>
  {myProfile ? (
    isEditing ? (
      <>
        {/* Profile Form */}
        <form
          onSubmit={handleEditSubmit}
          className="edit-profile-form"
          encType="multipart/form-data"
        >
          <div>
            <label>Username:</label>
            <input
              type="text"
              name="username"
              value={editForm.username}
              onChange={handleInputChange}
              required
            />
          </div>
          <div>
            <label>Bio:</label>
            <textarea
              name="bio"
              value={editForm.bio}
              onChange={handleInputChange}
            />
          </div>
          <div>
            <label>Profile Picture:</label>
            <input
              type="file"
              name="profile_pic"
              accept="image/*"
              onChange={handleFileChange}
            />
          </div>

          <button type="submit" className="save-btn">Save</button>
          <button
            type="button"
            onClick={() => setIsEditing(false)}
            className="cancel-btn"
          >
            Cancel
          </button>
        </form>

        {/* Favorite Genres Section (Now OUTSIDE the form) */}
        <div className="favorite-genres-section">
          <h3>Current Favorite Genres:</h3>
          <div className="current-favorites">
            {userFavoriteGenres.map((item) => (
              <div key={item.category_id} className="favorite-genre-item">
                {editingGenreId === item.category_id ? (
                  <div className="genre-edit-form">
                    <span className="category-name">{item.category_name}:</span>
                    <select
                      value={editGenreForm.genre}
                      onChange={(e) =>
                        setEditGenreForm({
                          ...editGenreForm,
                          genre: e.target.value,
                        })
                      }
                      className="genre-edit-select"
                    >
                      <option value={item.genre}>{item.genre}</option>
                      {genresForCategory[item.category_id]
                        ?.filter((g) => g !== item.genre)
                        .map((genre) => (
                          <option key={genre} value={genre}>
                            {genre}
                          </option>
                        ))}
                    </select>
                    <div className="edit-actions">
                      <button
                        type="button"
                        onClick={() =>
                          handleEditGenre(item.category_id, editGenreForm.genre)
                        }
                        className="save-edit-btn"
                      >
                        ✓
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setEditingGenreId(null);
                          setEditGenreForm({ category: "", genre: "" });
                        }}
                        className="cancel-edit-btn"
                      >
                        ✕
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="genre-display">
                    <span className="genre-text">
                      {item.category_name}: {item.genre}
                    </span>
                    <div className="genre-actions">
                      <button
                        onClick={async () => {
                          await fetchGenresForCategory(item.category_id);
                          setEditingGenreId(item.category_id);
                          setEditGenreForm({
                            category: item.category_id,
                            genre: item.genre,
                          });
                        }}
                        className="edit-genre-btn"
                      >
                        ✎
                      </button>
                      <button
                        onClick={() => handleDeleteGenre(item.category_id)}
                        className="delete-genre-btn"
                      >
                        ×
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          <h3>Add New Favorite Genre:</h3>
          <div className="genre-selections">
            {genreSelections.map((selection, index) => (
              <div key={selection.id} className="genre-selection-row">
                <select
                  value={selection.category}
                  onChange={(e) =>
                    handleCategorySelect(e.target.value, index)
                  }
                  className="category-select"
                >
                  <option value="">Select Category</option>
                  {availableCategories.map((category) => (
                    <option
                      key={category.category_id}
                      value={category.category_id}
                    >
                      {category.name}
                    </option>
                  ))}
                </select>

                <select
                  value={selection.genre}
                  onChange={(e) =>
                    handleGenreSelect(e.target.value, index)
                  }
                  className="genre-select"
                  disabled={!selection.category}
                >
                  <option value="">Select Genre</option>
                  {genresForCategory[selection.category]?.map((genre) => (
                    <option key={genre} value={genre}>
                      {genre}
                    </option>
                  ))}
                </select>

                <button
                  type="button"
                  onClick={() => saveFavoriteGenre(selection)}
                  className="add-genre-btn"
                  disabled={!selection.category || !selection.genre}
                >
                  save
                </button>
              </div>
            ))}
          </div>
        </div>
      </>
    ) : (
      <div className="my-profile-card">
        <img
          src={myProfile.profile_pic || "https://via.placeholder.com/150"}
          alt={myProfile.username}
          className="my-profile-pic"
          onClick={() =>
            openFullScreen(
              myProfile.profile_pic || "https://via.placeholder.com/150"
            )
          }
        />
        <h2>{myProfile.username}</h2>
        <p>{myProfile.bio || "No bio available"}</p>
        <button
          onClick={() => setIsEditing(true)}
          className="edit-profile-btn"
        >
          Edit Profile
        </button>
        <div className="follow-toggle-buttons">
          <button
            onClick={() => setShowFollowers(true)}
            className={`toggle-btn ${showFollowers ? "active" : ""}`}
          >
            Followers ({followers.length})
          </button>
          <button
            onClick={() => setShowFollowers(false)}
            className={`toggle-btn ${!showFollowers ? "active" : ""}`}
          >
            Following ({following.length})
          </button>
        </div>
        <div className="follow-list">
          {showFollowers ? (
            followers.length === 0 ? (
              <p>No followers yet</p>
            ) : (
              <ul className="follow-items">
                {followers.map((user) => (
                  <li
                    key={user.user_id}
                    className="follow-item"
                    onClick={() => goToUserProfile(user.user_id)}
                    style={{ cursor: "pointer" }}
                  >
                    <img
                      src={user.profile_pic || "https://via.placeholder.com/50"}
                      alt={user.username}
                      className="follow-pic"
                    />
                    <span>{user.username}</span>
                  </li>
                ))}
              </ul>
            )
          ) : following.length === 0 ? (
            <p>Not following anyone yet</p>
          ) : (
            <ul className="follow-items">
              {following.map((user) => (
                <li
                  key={user.user_id}
                  className="follow-item"
                  onClick={() => goToUserProfile(user.user_id)}
                  style={{ cursor: "pointer" }}
                >
                  <img
                    src={user.profile_pic || "https://via.placeholder.com/50"}
                    alt={user.username}
                    className="follow-pic"
                  />
                  <span>{user.username}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    )
  ) : (
    <p>Please log in to view your profile</p>
  )}
</div>


      <div className="my-items-status-section">
        <h2>My Items with Status</h2>
        <div className="category-filter">
          <label htmlFor="category-select">Filter by Category: </label>
          <select
            id="category-select"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
          >
            <option value="">All Categories</option>
            {categories.map((category) => (
              <option key={category.category_id} value={category.category_id}>
                {category.name}
              </option>
            ))}
          </select>
        </div>
        {statusError ? (
          <p>{statusError}</p>
        ) : Object.keys(itemsByStatus).length === 0 ? (
          <p>No items found with status for this category.</p>
        ) : (
          <div>
            {Object.keys(itemsByStatus).map((status) => (
              <div key={status} className="status-section">
                <h3>{status} ({itemsByStatus[status].length})</h3>
                {itemsByStatus[status].length > 0 ? (
                  <div className="item-list">
                    {itemsByStatus[status].map((item) => (
                      <div
                        key={item.item_id}
                        className="item-card"
                        onClick={() => navigate(`/item/${item.item_id}`)}
                        style={{ cursor: 'pointer' }}
                      >
                        <img src={item.image_url} alt={item.title} className="item-image" />
                        <p><strong>{item.title}</strong></p>
                        <p>{item.genre}</p>
                        <p>{item.release_year}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p>No items in this status.</p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="recommended-profiles-section">
        <h1>Recommended Users</h1>
        <div className="profiles-list">
          {profiles.map((profile) => (
            <div key={profile.user_id} className="profile-card">
              <img
                src={profile.profile_pic || 'https://via.placeholder.com/150'}
                alt={profile.username}
                className="profile-pic"
                onClick={() => goToUserProfile(profile.user_id)}
                style={{ cursor: 'pointer' }}
              />
              <h2 onClick={() => goToUserProfile(profile.user_id)} style={{ cursor: 'pointer' }}>
                {profile.username}
              </h2>
              <p>{profile.bio || 'No bio available'}</p>
              <button onClick={() => sendFriendRequest(profile.user_id)} className="friend-request-btn">
                Send Friend Request
              </button>
            </div>
          ))}
        </div>
      </div>

      {fullScreenImage && (
        <div className="fullscreen-overlay" onClick={closeFullScreen}>
          <img src={fullScreenImage} alt="Full screen profile" className="fullscreen-image" />
          <button className="close-fullscreen-btn" onClick={closeFullScreen}>Close</button>
        </div>
      )}
      <div style={{ marginTop: '40px' }}>
        <button
          onClick={() => navigate('/dashboard')}
          style={{ padding: '10px 20px', fontSize: '16px' }}
        >
          ⬅ Back to Dashboard
        </button>
      </div>
    </div>
  );
};

export default Profiles;