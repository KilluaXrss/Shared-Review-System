import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";

const ProfileDetail = () => {
  const { userId } = useParams();
  const [user, setUser] = useState(null);

  useEffect(() => {
    axios.get(`http://localhost:4000/profiles/${userId}`, { withCredentials: true })
      .then(res => setUser(res.data))
      .catch(err => console.log(err));
  }, [userId]);

  if (!user) return <div>Loading...</div>;

  return (
    <div>
      <h2>{user.username}'s Profile</h2>
      {/* You can display bio, avatar, etc. here */}
    </div>
  );
};

export default ProfileDetail;
