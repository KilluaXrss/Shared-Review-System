// (same imports)
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { useLocation } from "react-router";
import { apiUrl } from "../config/config";
import "../css/dashboard.css";
import animeBg from "../css/img3.jpg";

const Dashboard = () => {
  const location = useLocation();
  const [username, setUsername] = useState("User");
  const [searchTerm, setSearchTerm] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [searchResults, setSearchResults] = useState([]);
  const [recommendations, setRecommendations] = useState({});
  const navigate = useNavigate();
  useEffect(() => {
    if (location.state?.resetDashboard) {
      setSearchTerm("");
      setSuggestions([]);
      setSearchResults([]);
    }
  }, [location.state]);

  useEffect(() => {
    const checkStatus = async () => {
      try {
        const response = await fetch(`${apiUrl}/isLoggedIn`, {
          method: "GET",
          credentials: "include",
        });

        if (!response.ok) throw new Error("Not logged in");

        const data = await response.json();
        setUsername(data.username || "User");
      } catch (err) {
        console.log(err);
        navigate("/login");
      }
    };

    checkStatus();
  }, []);
    // New useEffect for fetching recommendations
    useEffect(() => {
      const fetchRecommendations = async () => {
        try {
          console.log('Fetching recommendations...');
          const response = await fetch(`${apiUrl}/api/recommendations`, {
            credentials: 'include'
          });
          console.log('Response status:', response.status);
          const data = await response.json();
          console.log('Recommendations data:', data);
          
          if (data.recommendations) {
            setRecommendations(data.recommendations);
          }
        } catch (error) {
          console.error('Failed to fetch recommendations:', error);
        }
      };
    
      fetchRecommendations();
    }, []);

  useEffect(() => {
    const fetchMatches = async () => {
      if (searchTerm.trim() === "") {
        setSuggestions([]);
        return;
      }

      try {
        const res = await fetch(
          `${apiUrl}/search?query=${encodeURIComponent(searchTerm)}`,
          { credentials: "include" }
        );

        if (res.ok) {
          const data = await res.json();
          setSuggestions(removeDuplicatesByTitle(data));
        } else {
          setSuggestions([]);
        }
      } catch (error) {
        console.error("Search suggestion fetch failed:", error);
        setSuggestions([]);
      }
    };

    const timer = setTimeout(fetchMatches, 300); // Debounce
    return () => clearTimeout(timer);
  }, [searchTerm]);

  const handleSearch = async () => {
    if (searchTerm.trim() === "") return;

    try {
      const res = await fetch(
        `${apiUrl}/search?query=${encodeURIComponent(searchTerm)}&detailed=true`,
        { credentials: "include" }
      );

      if (res.ok) {
        const data = await res.json();
        setSearchResults(removeDuplicatesByTitle(data));
        setSuggestions([]);
      } else {
        setSearchResults([]);
      }
    } catch (error) {
      console.error("Search failed:", error);
      setSearchResults([]);
    }
  };

  const handleSelectItem = (itemId) => {
    navigate(`/item/${itemId}`);
    setSuggestions([]);
    setSearchTerm("");
    setSearchResults([]);
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
      handleSearch();
    }
  };

  // ✨ Call this in your sidebar's Home button
  const goHome = () => {
    setSearchResults([]);
    setSuggestions([]);
    setSearchTerm("");
    navigate("/dashboard");
  };

  const removeDuplicatesByTitle = (items) => {
    const seen = new Set();
    return items.filter((item) => {
      if (seen.has(item.title.toLowerCase())) return false;
      seen.add(item.title.toLowerCase());
      return true;
    });
  };

  return (
    <div className="dashboard-outer">
      {/* Search bar pinned to top-right */}
      <div className="top-search-wrapper">
        <input
          type="text"
          className="top-search-input"
          placeholder="Search for items by title..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          onKeyPress={handleKeyPress}
        />
        <button className="top-search-button" onClick={handleSearch}>
          Search
        </button>

        {suggestions.length > 0 && (
          <div className="search-suggestions">
            {suggestions.map((item) => (
              <div
                key={item.item_id}
                className="suggestion-item"
                onClick={() => handleSelectItem(item.item_id)}
              >
                {item.title}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Content area */}
      <div className="content-area">
        {searchResults.length > 0 ? (
          <div className="search-results-container">
            <h2>Search Results</h2>
            <div className="search-results">
              {searchResults.map((item) => (
                <div
                  key={item.item_id}
                  className="result-item"
                  onClick={() => handleSelectItem(item.item_id)}
                >
                  <img src={item.image_url} alt={item.title} className="result-image" />
                  <div className="result-details">
                    <h3>{item.title}</h3>
                    <p>Release Year: {item.release_year || "N/A"}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="dashboard-container">
            <div className="dashboard-card">
              <div className="left-panel">
                <h1>
                  Hi, {username} <span role="img" aria-label="wave">👋</span>
                </h1>
                <p>
                  Welcome to the <span className="highlight">Ratings App</span>
                </p>
                <button className="watch-btn" onClick={() => navigate("/category")}>
                  Explore Now
                </button>
              </div>
              <div className="right-panel">
                <img src={animeBg} alt="anime-banner" />
              </div>
            </div>
         {/* New Recommendations Section */}
         <div className="recommendations-title">
  <h1>Recommendations</h1>
</div>
         <div className="recommendations-section">
         {console.log('Current recommendations:', recommendations)}
              {Object.entries(recommendations).map(([categoryId, categoryData]) => (
                <div key={categoryId} className="recommendation-category">
                  <h2>{categoryData.category_name}</h2>
                  <div className="recommendation-row">
                    {categoryData.items.map(item => (
                      <div 
                        key={item.item_id} 
                        className="recommendation-item"
                        onClick={() => handleSelectItem(item.item_id)}
                      >
                        <img 
                          src={item.image_url} 
                          alt={item.title} 
                          className="recommendation-image"
                        />
                        <h3>{item.title}</h3>
                        <div className="rating">
                          ⭐ {Number(item.average_rating).toFixed(1)}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
