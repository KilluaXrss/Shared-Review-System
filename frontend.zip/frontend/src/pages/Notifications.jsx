import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../css/Notifications.css';
import { useNavigate } from 'react-router';

axios.defaults.withCredentials = true;

const Notifications = () => {
  const [friendRequests, setFriendRequests] = useState([]);
  const [commentNotifications, setCommentNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const baseUrl = 'http://localhost:4000';

  // Normalize profile_pic path (same as Profiles.jsx)
  const normalizeProfilePic = (path) => {
    if (!path) return null;
    const normalized = path.replace('/uploads//uploads/', '/uploads/');
    return `${baseUrl}${normalized}`;
  };

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        // Fetch pending friend requests
        const friendResponse = await axios.get(`${baseUrl}/friends/pending`);
        console.log('Friend requests response:', friendResponse.data);
        const normalizedRequests = friendResponse.data.map((request) => ({
          ...request,
          profile_pic: normalizeProfilePic(request.profile_pic),
        }));
        setFriendRequests(normalizedRequests);

        // Fetch comment notifications
        const commentResponse = await axios.get(`${baseUrl}/notifications/comments`);
        console.log('Comment notifications response:', commentResponse.data);
        const normalizedComments = commentResponse.data.map((comment) => ({
          ...comment,
          profile_pic: normalizeProfilePic(comment.profile_pic || comment.user?.profile_pic || null),
        }));
        setCommentNotifications(normalizedComments);

        setLoading(false);
      } catch (err) {
        console.error('Fetch error:', err.response?.status, err.response?.data);
        setError(err.response?.data?.message || 'Failed to load notifications');
        setLoading(false);
      }
    };

    fetchNotifications();
  }, []);

  const acceptRequest = async (friendId) => {
    try {
      await axios.post(`${baseUrl}/friends/accept`, { friendId });
      setFriendRequests(friendRequests.filter((req) => req.user_id !== friendId));
      alert('Friend request accepted!');
    } catch (err) {
      alert('Error accepting friend request');
    }
  };

  const rejectRequest = async (friendId) => {
    try {
      await axios.post(`${baseUrl}/friends/reject`, { friendId });
      setFriendRequests(friendRequests.filter((req) => req.user_id !== friendId));
      alert('Friend request rejected!');
    } catch (err) {
      alert('Error rejecting friend request');
    }
  };

  // New function to clear only comment notifications
  const clearCommentNotifications = async () => {
    try {
      await axios.post(`${baseUrl}/notifications/comments/clear`, {}, { withCredentials: true });
      setCommentNotifications([]);
      alert('Comment notifications cleared!');
    } catch (err) {
      console.error('Clear comment notifications error:', err.response?.data || err.message);
      alert('Error clearing comment notifications: ' + (err.response?.data?.message || 'Unknown error'));
    }
  };

  if (loading) return <div>Loading notifications...</div>;
  if (error) return <div>{error}</div>;

  return (
    <div className="notifications-container">
      <h1>Notifications</h1>

      {/* Clear Comment Notifications Button */}
      <div style={{ marginBottom: '20px' }}>
        <button
          onClick={clearCommentNotifications}
          disabled={commentNotifications.length === 0}
          style={{
            padding: '10px 20px',
            fontSize: '16px',
            backgroundColor: commentNotifications.length === 0 ? '#ccc' : '#dc3545',
            color: '#fff',
            border: 'none',
            borderRadius: '5px',
            cursor: commentNotifications.length === 0 ? 'not-allowed' : 'pointer',
          }}
        >
          Clear Comment Notifications
        </button>
      </div>

      {/* Friend Requests Section */}
      <div className="friend-requests-section">
        <h2>Pending Friend Requests</h2>
        {friendRequests.length === 0 ? (
          <p>No pending friend requests</p>
        ) : (
          <ul className="requests-list">
            {friendRequests.map((request) => (
              <li key={request.user_id} className="request-item">
                <img
                  src={request.profile_pic || 'https://via.placeholder.com/50'}
                  alt={request.username}
                  className="request-pic"
                />
                <span>{request.username}</span>
                <div className="request-actions">
                  <button onClick={() => acceptRequest(request.user_id)} className="accept-btn">
                    Accept
                  </button>
                  <button onClick={() => rejectRequest(request.user_id)} className="reject-btn">
                    Reject
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Comment Notifications Section */}
      <div className="comment-notifications-section">
        <h2>Recent Comments on Your Reviews</h2>
        {commentNotifications.length === 0 ? (
          <p>No recent comments</p>
        ) : (
          <ul className="comments-list">
            {commentNotifications.map((comment) => (
              <li key={comment.comment_id} className="comment-item">
                <img
                  src={comment.profile_pic || 'https://via.placeholder.com/50'}
                  alt={comment.username}
                  className="comment-pic"
                />
                <div className="comment-details">
                  <span>
                    <strong>{comment.username}</strong> commented on your review of "{comment.item_title}":{' '}
                    {comment.comment_text}
                  </span>
                  <button
                    onClick={() => navigate(`/item/${comment.item_id}`)}
                    className="view-review-btn"
                  >
                    View Review
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div style={{ marginTop: '40px' }}>
        <button
          onClick={() => navigate('/dashboard')}
          style={{ padding: '10px 20px', fontSize: '16px' }}
        >
          ⬅ Back to Dashboard
        </button>
      </div>
    </div>
  );
};

export default Notifications;